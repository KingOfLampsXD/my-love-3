'use client'

import { Starfield } from '@/components/effects/starfield'
import { FloatingHearts } from '@/components/effects/floating-hearts'
import { Particles } from '@/components/effects/particles'
import { MouseTrail } from '@/components/effects/mouse-trail'
import { motion } from 'framer-motion'

export function UniverseBackground() {
  return (
    <div className="fixed inset-0 z-0">
      {/* Base gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#0a0012] via-[#1a0a2e] to-[#0d0015]" />
      
      {/* Aurora effect */}
      <motion.div
        className="absolute inset-0 opacity-30"
        style={{
          background: 'linear-gradient(45deg, transparent 0%, rgba(138,43,226,0.1) 25%, transparent 50%, rgba(255,105,180,0.1) 75%, transparent 100%)',
          backgroundSize: '400% 400%',
        }}
        animate={{
          backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
        }}
        transition={{
          duration: 15,
          repeat: Infinity,
          ease: 'linear',
        }}
      />

      {/* Vignette */}
      <div 
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse at center, transparent 0%, rgba(0,0,0,0.4) 100%)',
        }}
      />

      {/* Effects layers */}
      <Starfield count={200} />
      <FloatingHearts count={15} />
      <Particles type="ambient" />
      <MouseTrail />

      {/* Nebula clouds */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <motion.div
          className="absolute w-[600px] h-[600px] -top-40 -left-40 rounded-full opacity-20"
          style={{
            background: 'radial-gradient(circle, rgba(138,43,226,0.4) 0%, transparent 70%)',
            filter: 'blur(60px)',
          }}
          animate={{
            scale: [1, 1.2, 1],
            x: [0, 50, 0],
            y: [0, 30, 0],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        />
        <motion.div
          className="absolute w-[500px] h-[500px] -bottom-20 -right-20 rounded-full opacity-20"
          style={{
            background: 'radial-gradient(circle, rgba(255,105,180,0.4) 0%, transparent 70%)',
            filter: 'blur(60px)',
          }}
          animate={{
            scale: [1.2, 1, 1.2],
            x: [0, -30, 0],
            y: [0, -50, 0],
          }}
          transition={{
            duration: 25,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        />
      </div>
    </div>
  )
}
