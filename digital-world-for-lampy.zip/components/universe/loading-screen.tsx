'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'

interface LoadingScreenProps {
  onComplete: () => void
}

export function LoadingScreen({ onComplete }: LoadingScreenProps) {
  const [phase, setPhase] = useState(0)
  const [progress, setProgress] = useState(0)

  const loadingTexts = [
    "Entering Lampy & Rose Universe...",
    "Gathering stardust...",
    "Connecting hearts...",
    "Loading memories...",
    "Preparing your world...",
    "Almost there..."
  ]

  useEffect(() => {
    const progressInterval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(progressInterval)
          return 100
        }
        return prev + 2
      })
    }, 50)

    const phaseInterval = setInterval(() => {
      setPhase(prev => (prev + 1) % loadingTexts.length)
    }, 800)

    const completeTimeout = setTimeout(() => {
      onComplete()
    }, 3500)

    return () => {
      clearInterval(progressInterval)
      clearInterval(phaseInterval)
      clearTimeout(completeTimeout)
    }
  }, [onComplete])

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-[#0a0015]"
        initial={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.8 }}
      >
        {/* Background effects */}
        <div className="absolute inset-0 overflow-hidden">
          {/* Animated particles */}
          {Array.from({ length: 50 }).map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1 h-1 bg-pink-400 rounded-full"
              initial={{
                x: Math.random() * (typeof window !== 'undefined' ? window.innerWidth : 1000),
                y: Math.random() * (typeof window !== 'undefined' ? window.innerHeight : 1000),
                opacity: 0,
              }}
              animate={{
                opacity: [0, 0.8, 0],
                scale: [0, 1.5, 0],
              }}
              transition={{
                duration: 2,
                delay: i * 0.05,
                repeat: Infinity,
              }}
            />
          ))}
        </div>

        {/* Central heart formation */}
        <motion.div
          className="relative mb-12"
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ duration: 1, type: "spring" }}
        >
          {/* Outer glow */}
          <motion.div
            className="absolute inset-0 blur-2xl"
            animate={{
              scale: [1, 1.3, 1],
              opacity: [0.5, 0.8, 0.5],
            }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <div className="w-32 h-32 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full" />
          </motion.div>

          {/* Heart */}
          <motion.div
            className="relative text-8xl"
            animate={{
              scale: [1, 1.1, 1],
            }}
            transition={{
              duration: 0.8,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          >
            <span className="text-glow-pink">❤️</span>
          </motion.div>

          {/* Orbiting particles */}
          {[0, 60, 120, 180, 240, 300].map((angle, i) => (
            <motion.div
              key={i}
              className="absolute w-3 h-3 bg-pink-400 rounded-full"
              style={{
                top: '50%',
                left: '50%',
              }}
              animate={{
                x: [
                  Math.cos((angle * Math.PI) / 180) * 80,
                  Math.cos(((angle + 360) * Math.PI) / 180) * 80,
                ],
                y: [
                  Math.sin((angle * Math.PI) / 180) * 80,
                  Math.sin(((angle + 360) * Math.PI) / 180) * 80,
                ],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "linear",
              }}
            />
          ))}
        </motion.div>

        {/* Loading text */}
        <motion.div
          className="text-center mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <motion.h1
            className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-pink-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-4"
            animate={{ backgroundPosition: ['0%', '100%', '0%'] }}
            transition={{ duration: 3, repeat: Infinity }}
            style={{ backgroundSize: '200%' }}
          >
            Lampy ❤️ Rose
          </motion.h1>
          
          <AnimatePresence mode="wait">
            <motion.p
              key={phase}
              className="text-pink-300/80 text-lg"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
            >
              {loadingTexts[phase]}
            </motion.p>
          </AnimatePresence>
        </motion.div>

        {/* Progress bar */}
        <motion.div
          className="w-64 h-2 bg-white/10 rounded-full overflow-hidden"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
        >
          <motion.div
            className="h-full bg-gradient-to-r from-pink-500 via-purple-500 to-pink-500 rounded-full"
            style={{ width: `${progress}%` }}
            animate={{
              backgroundPosition: ['0%', '100%'],
            }}
            transition={{
              duration: 1,
              repeat: Infinity,
            }}
          />
        </motion.div>

        {/* Progress percentage */}
        <motion.p
          className="mt-4 text-pink-400/60 text-sm font-mono"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
        >
          {progress}%
        </motion.p>
      </motion.div>
    </AnimatePresence>
  )
}
