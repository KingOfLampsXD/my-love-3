'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import Link from 'next/link'
import { useUniverseStore } from '@/lib/store'

const worlds = [
  { 
    id: 'memory-forest',
    name: 'Memory Forest',
    icon: '🌲',
    description: 'Where our memories grow like trees',
    color: 'from-green-500/20 to-emerald-500/20',
    borderColor: 'border-green-500/30',
    path: '/universe/memories',
    position: { x: 10, y: 20 },
  },
  {
    id: 'heart-lake',
    name: 'Heart Lake',
    icon: '💕',
    description: 'A lake of endless love',
    color: 'from-pink-500/20 to-red-500/20',
    borderColor: 'border-pink-500/30',
    path: '/universe/heart-lake',
    position: { x: 65, y: 15 },
  },
  {
    id: 'arcade-planet',
    name: 'Arcade Planet',
    icon: '🎮',
    description: 'Play together, stay together',
    color: 'from-purple-500/20 to-blue-500/20',
    borderColor: 'border-purple-500/30',
    path: '/universe/arcade',
    position: { x: 35, y: 45 },
  },
  {
    id: 'music-island',
    name: 'Music Island',
    icon: '🎵',
    description: 'Our soundtrack of love',
    color: 'from-cyan-500/20 to-blue-500/20',
    borderColor: 'border-cyan-500/30',
    path: '/universe/music',
    position: { x: 75, y: 50 },
  },
  {
    id: 'dream-city',
    name: 'Dream City',
    icon: '🌙',
    description: 'Where dreams come true',
    color: 'from-indigo-500/20 to-purple-500/20',
    borderColor: 'border-indigo-500/30',
    path: '/universe/dreams',
    position: { x: 20, y: 65 },
  },
  {
    id: 'secret-cave',
    name: 'Secret Cave',
    icon: '✨',
    description: 'Hidden treasures await',
    color: 'from-amber-500/20 to-orange-500/20',
    borderColor: 'border-amber-500/30',
    path: '/universe/secrets',
    position: { x: 50, y: 75 },
  },
  {
    id: 'love-library',
    name: 'Love Library',
    icon: '💌',
    description: 'Our collection of letters',
    color: 'from-rose-500/20 to-pink-500/20',
    borderColor: 'border-rose-500/30',
    path: '/universe/letters',
    position: { x: 85, y: 30 },
  },
  {
    id: 'cozy-room',
    name: 'Cozy Night Room',
    icon: '🌌',
    description: 'Our safe space',
    color: 'from-slate-500/20 to-gray-500/20',
    borderColor: 'border-slate-500/30',
    path: '/universe/cozy',
    position: { x: 5, y: 45 },
  },
]

export function WorldMap() {
  const [hoveredWorld, setHoveredWorld] = useState<string | null>(null)
  const { addDiscovery, discoveries } = useUniverseStore()

  const handleWorldClick = (worldId: string) => {
    if (!discoveries.includes(`visited-${worldId}`)) {
      addDiscovery(`visited-${worldId}`)
    }
  }

  return (
    <div className="relative">
      {/* Map container */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {worlds.map((world, index) => (
          <Link 
            key={world.id} 
            href={world.path}
            onClick={() => handleWorldClick(world.id)}
          >
            <motion.div
              className={`glass rounded-2xl p-5 border ${world.borderColor} cursor-pointer relative overflow-hidden group`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.05, y: -5 }}
              whileTap={{ scale: 0.98 }}
              onHoverStart={() => setHoveredWorld(world.id)}
              onHoverEnd={() => setHoveredWorld(null)}
            >
              {/* Background gradient */}
              <div className={`absolute inset-0 bg-gradient-to-br ${world.color} opacity-50 group-hover:opacity-100 transition-opacity`} />
              
              {/* Glow effect on hover */}
              <motion.div
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity"
                style={{
                  background: 'radial-gradient(circle at center, rgba(255,255,255,0.1) 0%, transparent 70%)',
                }}
              />

              {/* Content */}
              <div className="relative z-10">
                <motion.div
                  className="text-4xl mb-3"
                  animate={hoveredWorld === world.id ? {
                    scale: [1, 1.2, 1],
                    rotate: [0, 10, -10, 0],
                  } : {}}
                  transition={{ duration: 0.5 }}
                >
                  {world.icon}
                </motion.div>
                <h3 className="font-semibold text-foreground mb-1">{world.name}</h3>
                <p className="text-xs text-muted-foreground">{world.description}</p>

                {/* Visited badge */}
                {discoveries.includes(`visited-${world.id}`) && (
                  <motion.div
                    className="absolute top-2 right-2 w-6 h-6 bg-green-500/30 rounded-full flex items-center justify-center"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                  >
                    <span className="text-xs">✓</span>
                  </motion.div>
                )}
              </div>

              {/* Animated particles */}
              {hoveredWorld === world.id && (
                <div className="absolute inset-0 pointer-events-none">
                  {[...Array(5)].map((_, i) => (
                    <motion.div
                      key={i}
                      className="absolute w-1 h-1 bg-white rounded-full"
                      initial={{
                        x: Math.random() * 100 + '%',
                        y: '100%',
                        opacity: 0,
                      }}
                      animate={{
                        y: '0%',
                        opacity: [0, 1, 0],
                      }}
                      transition={{
                        duration: 1,
                        delay: i * 0.1,
                        repeat: Infinity,
                      }}
                    />
                  ))}
                </div>
              )}
            </motion.div>
          </Link>
        ))}
      </div>

      {/* Discovery counter */}
      <motion.div
        className="mt-6 text-center"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.8 }}
      >
        <p className="text-sm text-muted-foreground">
          Worlds Explored: {' '}
          <span className="text-pink-400 font-semibold">
            {discoveries.filter(d => d.startsWith('visited-')).length}
          </span>
          {' '} / {worlds.length}
        </p>
      </motion.div>
    </div>
  )
}
