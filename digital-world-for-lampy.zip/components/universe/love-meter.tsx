'use client'

import { motion } from 'framer-motion'
import { useUniverseStore } from '@/stores/universe-store'

export function LoveMeter() {
  const { loveMeter, setLoveMeter } = useUniverseStore()

  const handleClick = () => {
    setLoveMeter(Math.min(100, loveMeter + 5))
  }

  return (
    <motion.div
      className="glass-pink rounded-2xl p-4 cursor-pointer select-none"
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      onClick={handleClick}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <div className="flex items-center gap-3">
        <motion.span 
          className="text-2xl"
          animate={{ scale: [1, 1.2, 1] }}
          transition={{ duration: 1.5, repeat: Infinity }}
        >
          ❤
        </motion.span>
        <div className="flex-1">
          <p className="text-xs text-muted-foreground mb-1">Love Meter</p>
          <div className="h-3 bg-muted/50 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-pink-500 to-pink-400 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${loveMeter}%` }}
              transition={{ duration: 0.5, ease: 'easeOut' }}
            />
          </div>
        </div>
        <span className="text-sm font-bold text-pink-400">{loveMeter}%</span>
      </div>
      <p className="text-[10px] text-muted-foreground mt-1 text-center">
        Click to fill with love!
      </p>
    </motion.div>
  )
}

export function ChaosMeter() {
  const { chaosLevel } = useUniverseStore()

  return (
    <motion.div
      className="glass-purple rounded-2xl p-4"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 }}
    >
      <div className="flex items-center gap-3">
        <span className="text-2xl">✨</span>
        <div className="flex-1">
          <p className="text-xs text-muted-foreground mb-1">Chaos Level</p>
          <div className="h-3 bg-muted/50 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-purple-500 to-purple-400 rounded-full"
              style={{ width: `${chaosLevel}%` }}
            />
          </div>
        </div>
        <span className="text-sm font-bold text-purple-400">{chaosLevel}%</span>
      </div>
    </motion.div>
  )
}

export function HeartbeatIndicator() {
  return (
    <motion.div
      className="flex items-center gap-2 glass rounded-full px-4 py-2"
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
    >
      <motion.div
        className="w-3 h-3 rounded-full bg-pink-500"
        animate={{
          scale: [1, 1.3, 1, 1.3, 1],
          boxShadow: [
            '0 0 0 0 rgba(255, 105, 180, 0.7)',
            '0 0 0 10px rgba(255, 105, 180, 0)',
            '0 0 0 0 rgba(255, 105, 180, 0)',
            '0 0 0 10px rgba(255, 105, 180, 0)',
            '0 0 0 0 rgba(255, 105, 180, 0)',
          ],
        }}
        transition={{
          duration: 1.5,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />
      <span className="text-xs text-muted-foreground">Hearts beating as one</span>
    </motion.div>
  )
}
