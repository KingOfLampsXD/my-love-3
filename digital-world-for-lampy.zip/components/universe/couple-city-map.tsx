'use client'

import { motion } from 'framer-motion'
import Link from 'next/link'
import { useState } from 'react'

interface WorldLocation {
  id: string
  name: string
  icon: string
  description: string
  path: string
  color: string
  glowColor: string
  position: { x: number; y: number }
  unlocked: boolean
}

const WORLD_LOCATIONS: WorldLocation[] = [
  {
    id: 'memory-forest',
    name: 'Memory Forest',
    icon: '🌲',
    description: 'A magical forest where every tree holds a precious memory',
    path: '/worlds/memory-forest',
    color: 'from-emerald-500 to-teal-600',
    glowColor: 'rgba(16, 185, 129, 0.5)',
    position: { x: 15, y: 25 },
    unlocked: true,
  },
  {
    id: 'heart-lake',
    name: 'Heart Lake',
    icon: '💕',
    description: 'A serene lake shaped like a heart, where love flows eternally',
    path: '/worlds/heart-lake',
    color: 'from-pink-500 to-rose-600',
    glowColor: 'rgba(236, 72, 153, 0.5)',
    position: { x: 45, y: 15 },
    unlocked: true,
  },
  {
    id: 'arcade-planet',
    name: 'Arcade Planet',
    icon: '🎮',
    description: 'A vibrant planet filled with games and challenges for two',
    path: '/worlds/arcade-planet',
    color: 'from-violet-500 to-purple-600',
    glowColor: 'rgba(139, 92, 246, 0.5)',
    position: { x: 75, y: 20 },
    unlocked: true,
  },
  {
    id: 'music-island',
    name: 'Music Island',
    icon: '🎵',
    description: 'An island where melodies paint the sky and rhythm moves the soul',
    path: '/worlds/music-island',
    color: 'from-cyan-500 to-blue-600',
    glowColor: 'rgba(6, 182, 212, 0.5)',
    position: { x: 85, y: 50 },
    unlocked: true,
  },
  {
    id: 'dream-city',
    name: 'Dream City',
    icon: '🌙',
    description: 'A mystical city that exists only in the realm of dreams',
    path: '/worlds/dream-city',
    color: 'from-indigo-500 to-blue-700',
    glowColor: 'rgba(99, 102, 241, 0.5)',
    position: { x: 50, y: 45 },
    unlocked: true,
  },
  {
    id: 'secret-cave',
    name: 'Secret Cave',
    icon: '✨',
    description: 'A hidden cave filled with sparkling secrets and surprises',
    path: '/worlds/secret-cave',
    color: 'from-amber-500 to-orange-600',
    glowColor: 'rgba(245, 158, 11, 0.5)',
    position: { x: 25, y: 55 },
    unlocked: true,
  },
  {
    id: 'future-world',
    name: 'Future World',
    icon: '🚀',
    description: 'A glimpse into our future adventures together',
    path: '/worlds/future-world',
    color: 'from-sky-500 to-cyan-600',
    glowColor: 'rgba(14, 165, 233, 0.5)',
    position: { x: 70, y: 70 },
    unlocked: true,
  },
  {
    id: 'cozy-room',
    name: 'Cozy Night Room',
    icon: '🌌',
    description: 'Our cozy sanctuary under the stars',
    path: '/worlds/cozy-room',
    color: 'from-purple-500 to-fuchsia-600',
    glowColor: 'rgba(168, 85, 247, 0.5)',
    position: { x: 35, y: 75 },
    unlocked: true,
  },
  {
    id: 'mystery-house',
    name: 'Mystery House',
    icon: '🎁',
    description: 'A house full of surprises waiting to be discovered',
    path: '/worlds/mystery-house',
    color: 'from-red-500 to-pink-600',
    glowColor: 'rgba(239, 68, 68, 0.5)',
    position: { x: 10, y: 70 },
    unlocked: true,
  },
  {
    id: 'love-library',
    name: 'Love Library',
    icon: '💌',
    description: 'A grand library of love letters and sweet messages',
    path: '/worlds/love-library',
    color: 'from-rose-500 to-pink-600',
    glowColor: 'rgba(244, 63, 94, 0.5)',
    position: { x: 60, y: 80 },
    unlocked: true,
  },
  {
    id: 'sky-kingdom',
    name: 'Sky Kingdom',
    icon: '☁️',
    description: 'A floating kingdom among the clouds',
    path: '/worlds/sky-kingdom',
    color: 'from-blue-400 to-indigo-500',
    glowColor: 'rgba(96, 165, 250, 0.5)',
    position: { x: 90, y: 85 },
    unlocked: true,
  },
]

export function CoupleCityMap() {
  const [hoveredWorld, setHoveredWorld] = useState<string | null>(null)

  return (
    <div className="relative w-full aspect-[16/10] max-w-5xl mx-auto">
      {/* Connection lines */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none z-0">
        <defs>
          <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="rgba(255, 105, 180, 0.3)" />
            <stop offset="100%" stopColor="rgba(138, 43, 226, 0.3)" />
          </linearGradient>
        </defs>
        {WORLD_LOCATIONS.map((location, i) => {
          const nextLocation = WORLD_LOCATIONS[(i + 1) % WORLD_LOCATIONS.length]
          return (
            <motion.line
              key={`line-${i}`}
              x1={`${location.position.x}%`}
              y1={`${location.position.y}%`}
              x2={`${nextLocation.position.x}%`}
              y2={`${nextLocation.position.y}%`}
              stroke="url(#lineGradient)"
              strokeWidth="2"
              strokeDasharray="5,5"
              initial={{ pathLength: 0, opacity: 0 }}
              animate={{ pathLength: 1, opacity: 0.5 }}
              transition={{ duration: 2, delay: i * 0.1 }}
            />
          )
        })}
      </svg>

      {/* World locations */}
      {WORLD_LOCATIONS.map((location, index) => (
        <motion.div
          key={location.id}
          className="absolute z-10"
          style={{
            left: `${location.position.x}%`,
            top: `${location.position.y}%`,
            transform: 'translate(-50%, -50%)',
          }}
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ 
            type: 'spring',
            stiffness: 200,
            delay: index * 0.1 
          }}
        >
          <Link href={location.path}>
            <motion.div
              className="relative group cursor-pointer"
              onHoverStart={() => setHoveredWorld(location.id)}
              onHoverEnd={() => setHoveredWorld(null)}
              whileHover={{ scale: 1.2 }}
              whileTap={{ scale: 0.9 }}
            >
              {/* Glow effect */}
              <motion.div
                className="absolute inset-0 rounded-full blur-xl"
                style={{ backgroundColor: location.glowColor }}
                animate={{
                  scale: hoveredWorld === location.id ? [1, 1.5, 1] : 1,
                  opacity: hoveredWorld === location.id ? [0.5, 0.8, 0.5] : 0.3,
                }}
                transition={{ duration: 1.5, repeat: Infinity }}
              />

              {/* Main circle */}
              <div
                className={`relative w-16 h-16 md:w-20 md:h-20 rounded-full bg-gradient-to-br ${location.color} flex items-center justify-center shadow-lg`}
              >
                <span className="text-2xl md:text-3xl">{location.icon}</span>
              </div>

              {/* Pulse ring */}
              <motion.div
                className="absolute inset-0 rounded-full border-2"
                style={{ borderColor: location.glowColor }}
                animate={{
                  scale: [1, 1.5, 1],
                  opacity: [0.8, 0, 0.8],
                }}
                transition={{ duration: 2, repeat: Infinity }}
              />

              {/* Label */}
              <motion.div
                className="absolute left-1/2 -bottom-8 -translate-x-1/2 whitespace-nowrap"
                initial={{ opacity: 0, y: -5 }}
                animate={{ 
                  opacity: hoveredWorld === location.id ? 1 : 0.7,
                  y: 0 
                }}
              >
                <span className="text-xs md:text-sm font-medium text-foreground/90 drop-shadow-lg">
                  {location.name}
                </span>
              </motion.div>

              {/* Tooltip */}
              <motion.div
                className="absolute left-1/2 -translate-x-1/2 bottom-full mb-4 w-48 glass rounded-lg p-3 pointer-events-none"
                initial={{ opacity: 0, y: 10, scale: 0.9 }}
                animate={{
                  opacity: hoveredWorld === location.id ? 1 : 0,
                  y: hoveredWorld === location.id ? 0 : 10,
                  scale: hoveredWorld === location.id ? 1 : 0.9,
                }}
              >
                <p className="text-xs text-foreground/80 text-center">
                  {location.description}
                </p>
                <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1/2 rotate-45 w-2 h-2 glass" />
              </motion.div>
            </motion.div>
          </Link>
        </motion.div>
      ))}

      {/* Center decoration */}
      <motion.div
        className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-0"
        initial={{ opacity: 0, scale: 0 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 1, duration: 1 }}
      >
        <div className="relative">
          <motion.div
            className="w-24 h-24 rounded-full bg-gradient-to-br from-pink-500/20 to-purple-500/20 blur-2xl"
            animate={{
              scale: [1, 1.2, 1],
              opacity: [0.5, 0.8, 0.5],
            }}
            transition={{ duration: 4, repeat: Infinity }}
          />
        </div>
      </motion.div>
    </div>
  )
}
