'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'

export function DaysTogether() {
  const [days, setDays] = useState(0)
  const [showConfetti, setShowConfetti] = useState(false)
  
  // Set your relationship start date here
  const startDate = new Date('2024-01-01')

  useEffect(() => {
    const calculateDays = () => {
      const now = new Date()
      const diff = Math.floor((now.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24))
      setDays(diff)
    }
    calculateDays()
    const interval = setInterval(calculateDays, 60000)
    return () => clearInterval(interval)
  }, [])

  const handleClick = () => {
    setShowConfetti(true)
    setTimeout(() => setShowConfetti(false), 2000)
  }

  return (
    <motion.div
      className="glass rounded-2xl p-6 border border-purple-500/20 cursor-pointer relative overflow-hidden"
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      onClick={handleClick}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 }}
    >
      {/* Confetti effect */}
      {showConfetti && (
        <div className="absolute inset-0 pointer-events-none">
          {Array.from({ length: 15 }).map((_, i) => (
            <motion.div
              key={i}
              className="absolute text-xl"
              initial={{
                x: '50%',
                y: '50%',
                opacity: 1,
              }}
              animate={{
                x: `${Math.random() * 100}%`,
                y: `${Math.random() * 100}%`,
                opacity: 0,
                rotate: Math.random() * 360,
              }}
              transition={{ duration: 1 }}
            >
              {['✨', '💕', '🌟', '💫'][Math.floor(Math.random() * 4)]}
            </motion.div>
          ))}
        </div>
      )}

      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-medium text-muted-foreground">Days Together</h3>
        <motion.span
          className="text-2xl"
          animate={{ rotate: [0, 10, -10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          📅
        </motion.span>
      </div>
      
      <div className="text-center">
        <motion.span
          className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent"
          key={days}
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
        >
          {days}
        </motion.span>
        <p className="text-sm text-muted-foreground mt-1">days of love</p>
      </div>

      <p className="text-xs text-center text-pink-400/60 mt-4">
        Since {startDate.toLocaleDateString()}
      </p>
    </motion.div>
  )
}
