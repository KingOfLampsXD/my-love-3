'use client'

import { motion } from 'framer-motion'
import { useUniverseStore } from '@/lib/store'

export function HeartMeter() {
  const { loveMeter, setLoveMeter } = useUniverseStore()

  const handleClick = () => {
    setLoveMeter(Math.min(100, loveMeter + 1))
  }

  return (
    <motion.div
      className="glass rounded-2xl p-6 border border-pink-500/20 cursor-pointer"
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      onClick={handleClick}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-medium text-muted-foreground">Love Meter</h3>
        <motion.span
          className="text-2xl"
          animate={{ scale: [1, 1.2, 1] }}
          transition={{ duration: 1, repeat: Infinity }}
        >
          ❤️
        </motion.span>
      </div>
      
      <div className="relative h-4 bg-black/30 rounded-full overflow-hidden mb-2">
        <motion.div
          className="absolute inset-y-0 left-0 bg-gradient-to-r from-pink-500 via-red-500 to-pink-500 rounded-full"
          initial={{ width: 0 }}
          animate={{ width: `${loveMeter}%` }}
          transition={{ duration: 0.5 }}
        />
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent"
          animate={{ x: ['-100%', '100%'] }}
          transition={{ duration: 2, repeat: Infinity }}
        />
      </div>
      
      <div className="flex justify-between items-center">
        <span className="text-3xl font-bold text-pink-400">{loveMeter}%</span>
        <span className="text-xs text-muted-foreground">Click to add love!</span>
      </div>
    </motion.div>
  )
}
