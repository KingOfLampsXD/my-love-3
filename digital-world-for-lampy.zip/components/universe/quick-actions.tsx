'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'

interface QuickActionsProps {
  onSendHeart: () => void
}

export function QuickActions({ onSendHeart }: QuickActionsProps) {
  const [hearts, setHearts] = useState<{ id: number; x: number; y: number }[]>([])
  const [showMessage, setShowMessage] = useState(false)

  const handleSendHeart = () => {
    onSendHeart()
    
    // Create floating hearts
    const newHearts = Array.from({ length: 5 }, (_, i) => ({
      id: Date.now() + i,
      x: Math.random() * 100,
      y: 0,
    }))
    
    setHearts(prev => [...prev, ...newHearts])
    setShowMessage(true)
    
    setTimeout(() => {
      setHearts(prev => prev.filter(h => !newHearts.find(nh => nh.id === h.id)))
      setShowMessage(false)
    }, 2000)
  }

  const actions = [
    { icon: '❤️', label: 'Send Heart', action: handleSendHeart },
    { icon: '😘', label: 'Send Kiss', action: () => {} },
    { icon: '🤗', label: 'Send Hug', action: () => {} },
  ]

  return (
    <motion.div
      className="glass rounded-2xl p-6 border border-pink-500/20 relative overflow-hidden"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
    >
      {/* Floating hearts animation */}
      <AnimatePresence>
        {hearts.map((heart) => (
          <motion.div
            key={heart.id}
            className="absolute text-2xl pointer-events-none"
            initial={{ 
              left: `${heart.x}%`, 
              bottom: 0,
              opacity: 1,
            }}
            animate={{ 
              bottom: '100%',
              opacity: 0,
            }}
            exit={{ opacity: 0 }}
            transition={{ duration: 2, ease: 'easeOut' }}
          >
            ❤️
          </motion.div>
        ))}
      </AnimatePresence>

      {/* Success message */}
      <AnimatePresence>
        {showMessage && (
          <motion.div
            className="absolute inset-0 flex items-center justify-center bg-black/50 z-10"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.p
              className="text-pink-400 font-semibold"
              initial={{ scale: 0.5 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.5 }}
            >
              Heart Sent! ❤️
            </motion.p>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-medium text-muted-foreground">Quick Actions</h3>
        <span className="text-2xl">💝</span>
      </div>

      <div className="flex gap-2">
        {actions.map((action, index) => (
          <motion.button
            key={action.label}
            className="flex-1 py-3 rounded-xl bg-gradient-to-r from-pink-500/20 to-purple-500/20 hover:from-pink-500/30 hover:to-purple-500/30 border border-pink-500/30 flex flex-col items-center gap-1 transition-colors"
            onClick={action.action}
            whileHover={{ scale: 1.05, y: -2 }}
            whileTap={{ scale: 0.95 }}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 + index * 0.1 }}
          >
            <span className="text-xl">{action.icon}</span>
            <span className="text-xs text-muted-foreground">{action.label}</span>
          </motion.button>
        ))}
      </div>
    </motion.div>
  )
}
