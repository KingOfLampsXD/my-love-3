'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { useUniverseStore } from '@/lib/store'
import { Button } from '@/components/ui/button'

const navItems = [
  { name: 'Home', path: '/universe', icon: '🏠' },
  { name: 'Map', path: '/universe/map', icon: '🗺️' },
  { name: 'Games', path: '/universe/arcade', icon: '🎮' },
  { name: 'Music', path: '/universe/music', icon: '🎵' },
  { name: 'Letters', path: '/universe/letters', icon: '💌' },
]

export function UniverseNav() {
  const pathname = usePathname()
  const router = useRouter()
  const supabase = createClient()
  const { currentUser, partner, loveMeter } = useUniverseStore()
  const [showMenu, setShowMenu] = useState(false)
  const [currentTime, setCurrentTime] = useState(new Date())

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  const handleLogout = async () => {
    await supabase.auth.signOut()
    router.push('/auth/login')
  }

  return (
    <nav className="fixed top-0 left-0 right-0 z-50">
      <div className="glass border-b border-pink-500/20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link href="/universe" className="flex items-center gap-2">
              <motion.span
                className="text-2xl"
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              >
                ❤️
              </motion.span>
              <span className="font-bold text-pink-400 hidden sm:block">
                Lampy & Rose
              </span>
            </Link>

            {/* Desktop nav */}
            <div className="hidden md:flex items-center gap-1">
              {navItems.map((item) => (
                <Link key={item.path} href={item.path}>
                  <motion.div
                    className={`px-4 py-2 rounded-xl flex items-center gap-2 transition-colors ${
                      pathname === item.path
                        ? 'bg-pink-500/20 text-pink-400'
                        : 'hover:bg-white/5 text-muted-foreground hover:text-foreground'
                    }`}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <span>{item.icon}</span>
                    <span className="text-sm">{item.name}</span>
                  </motion.div>
                </Link>
              ))}
            </div>

            {/* Right side */}
            <div className="flex items-center gap-4">
              {/* Love meter */}
              <motion.div
                className="hidden sm:flex items-center gap-2 px-3 py-1 rounded-full bg-pink-500/10 border border-pink-500/30"
                whileHover={{ scale: 1.05 }}
              >
                <span className="text-sm">❤️</span>
                <div className="w-16 h-2 bg-black/30 rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-pink-500 to-red-500"
                    initial={{ width: 0 }}
                    animate={{ width: `${loveMeter}%` }}
                    transition={{ duration: 1 }}
                  />
                </div>
                <span className="text-xs text-pink-400">{loveMeter}%</span>
              </motion.div>

              {/* Time */}
              <div className="hidden lg:block text-sm text-muted-foreground">
                {currentTime.toLocaleTimeString()}
              </div>

              {/* Profile button */}
              <motion.button
                className="flex items-center gap-2 px-3 py-2 rounded-xl hover:bg-white/5 transition-colors"
                onClick={() => setShowMenu(!showMenu)}
                whileHover={{ scale: 1.05 }}
              >
                <span className="text-lg">
                  {currentUser?.display_name === 'Lampy' ? '🌟' : '🌹'}
                </span>
                <span className="text-sm text-pink-400 hidden sm:block">
                  {currentUser?.display_name || 'User'}
                </span>
              </motion.button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile bottom nav */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 glass border-t border-pink-500/20">
        <div className="flex justify-around py-2">
          {navItems.map((item) => (
            <Link key={item.path} href={item.path}>
              <motion.div
                className={`p-3 rounded-xl flex flex-col items-center ${
                  pathname === item.path
                    ? 'text-pink-400'
                    : 'text-muted-foreground'
                }`}
                whileTap={{ scale: 0.9 }}
              >
                <span className="text-xl">{item.icon}</span>
                <span className="text-xs mt-1">{item.name}</span>
              </motion.div>
            </Link>
          ))}
        </div>
      </div>

      {/* Dropdown menu */}
      <AnimatePresence>
        {showMenu && (
          <motion.div
            className="absolute right-4 top-20 glass rounded-2xl p-4 min-w-64 border border-pink-500/20"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
          >
            {/* User info */}
            <div className="flex items-center gap-3 pb-4 border-b border-white/10">
              <div className="w-12 h-12 rounded-full bg-gradient-to-r from-pink-500 to-purple-500 flex items-center justify-center text-2xl">
                {currentUser?.display_name === 'Lampy' ? '🌟' : '🌹'}
              </div>
              <div>
                <p className="font-semibold text-foreground">{currentUser?.display_name}</p>
                <p className="text-sm text-muted-foreground flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-green-400" />
                  Online
                </p>
              </div>
            </div>

            {/* Partner status */}
            {partner && (
              <div className="flex items-center gap-3 py-4 border-b border-white/10">
                <div className="w-10 h-10 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center text-xl">
                  {partner.display_name === 'Lampy' ? '🌟' : '🌹'}
                </div>
                <div>
                  <p className="text-sm text-foreground">{partner.display_name}</p>
                  <p className="text-xs text-pink-400">
                    {partner.status === 'online' ? '❤️ Online' : '💤 Away'}
                  </p>
                </div>
              </div>
            )}

            {/* Menu items */}
            <div className="py-2 space-y-1">
              <Link href="/universe/profile" onClick={() => setShowMenu(false)}>
                <motion.div
                  className="px-3 py-2 rounded-lg hover:bg-white/5 text-muted-foreground hover:text-foreground transition-colors"
                  whileHover={{ x: 5 }}
                >
                  Profile Settings
                </motion.div>
              </Link>
              <Link href="/universe/achievements" onClick={() => setShowMenu(false)}>
                <motion.div
                  className="px-3 py-2 rounded-lg hover:bg-white/5 text-muted-foreground hover:text-foreground transition-colors"
                  whileHover={{ x: 5 }}
                >
                  Achievements
                </motion.div>
              </Link>
              <Link href="/universe/secrets" onClick={() => setShowMenu(false)}>
                <motion.div
                  className="px-3 py-2 rounded-lg hover:bg-white/5 text-muted-foreground hover:text-foreground transition-colors"
                  whileHover={{ x: 5 }}
                >
                  Secret World
                </motion.div>
              </Link>
            </div>

            {/* Logout */}
            <div className="pt-2 border-t border-white/10">
              <Button
                variant="ghost"
                className="w-full text-red-400 hover:text-red-300 hover:bg-red-500/10"
                onClick={handleLogout}
              >
                Leave Universe
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Click outside to close */}
      {showMenu && (
        <div
          className="fixed inset-0 z-[-1]"
          onClick={() => setShowMenu(false)}
        />
      )}
    </nav>
  )
}
