'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { createClient } from '@/lib/supabase/client'
import { useUniverseStore } from '@/lib/store'

const moods = [
  { emoji: '😊', name: 'Happy', color: 'from-yellow-400 to-orange-400' },
  { emoji: '🥰', name: 'Loved', color: 'from-pink-400 to-red-400' },
  { emoji: '😴', name: 'Sleepy', color: 'from-blue-400 to-purple-400' },
  { emoji: '🤗', name: 'Cuddly', color: 'from-pink-400 to-purple-400' },
  { emoji: '😤', name: 'Playful', color: 'from-orange-400 to-red-400' },
  { emoji: '🥺', name: 'Miss You', color: 'from-purple-400 to-pink-400' },
]

export function MoodSelector() {
  const [isOpen, setIsOpen] = useState(false)
  const [selectedMood, setSelectedMood] = useState(moods[0])
  const { currentUser } = useUniverseStore()
  const supabase = createClient()

  const handleMoodSelect = async (mood: typeof moods[0]) => {
    setSelectedMood(mood)
    setIsOpen(false)

    if (currentUser?.id) {
      await supabase
        .from('profiles')
        .update({ mood: mood.name })
        .eq('id', currentUser.id)

      await supabase
        .from('mood_logs')
        .insert({
          user_id: currentUser.id,
          mood: mood.name,
        })
    }
  }

  return (
    <motion.div
      className="glass rounded-2xl p-6 border border-pink-500/20 relative"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-medium text-muted-foreground">Current Mood</h3>
        <span className="text-xs text-pink-400">Tap to change</span>
      </div>

      <motion.button
        className="w-full flex items-center justify-center gap-3 py-3 rounded-xl bg-gradient-to-r hover:opacity-90 transition-opacity"
        style={{
          backgroundImage: `linear-gradient(to right, var(--tw-gradient-from), var(--tw-gradient-to))`,
        }}
        onClick={() => setIsOpen(!isOpen)}
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
      >
        <motion.span
          className="text-3xl"
          animate={{ rotate: [0, 10, -10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          {selectedMood.emoji}
        </motion.span>
        <span className="font-semibold text-lg text-white">{selectedMood.name}</span>
      </motion.button>

      {/* Mood picker dropdown */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="absolute left-0 right-0 top-full mt-2 glass rounded-xl p-3 border border-pink-500/20 z-20"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
          >
            <div className="grid grid-cols-3 gap-2">
              {moods.map((mood) => (
                <motion.button
                  key={mood.name}
                  className={`p-3 rounded-lg flex flex-col items-center gap-1 transition-colors ${
                    selectedMood.name === mood.name
                      ? 'bg-pink-500/30'
                      : 'hover:bg-white/5'
                  }`}
                  onClick={() => handleMoodSelect(mood)}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <span className="text-2xl">{mood.emoji}</span>
                  <span className="text-xs text-muted-foreground">{mood.name}</span>
                </motion.button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Click outside to close */}
      {isOpen && (
        <div
          className="fixed inset-0 z-10"
          onClick={() => setIsOpen(false)}
        />
      )}
    </motion.div>
  )
}
