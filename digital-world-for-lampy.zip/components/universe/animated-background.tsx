'use client'

import { useEffect, useState, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'

interface Star {
  id: number
  x: number
  y: number
  size: number
  delay: number
  duration: number
}

interface Heart {
  id: number
  x: number
  y: number
  size: number
  delay: number
}

interface ShootingStar {
  id: number
  x: number
  y: number
}

export function AnimatedBackground() {
  const [stars, setStars] = useState<Star[]>([])
  const [hearts, setHearts] = useState<Heart[]>([])
  const [shootingStars, setShootingStars] = useState<ShootingStar[]>([])
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    // Generate stars
    const generatedStars: Star[] = Array.from({ length: 100 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 3 + 1,
      delay: Math.random() * 5,
      duration: Math.random() * 3 + 2,
    }))
    setStars(generatedStars)

    // Generate floating hearts
    const generatedHearts: Heart[] = Array.from({ length: 15 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 20 + 10,
      delay: Math.random() * 10,
    }))
    setHearts(generatedHearts)
  }, [])

  // Shooting stars effect
  useEffect(() => {
    if (!mounted) return
    const interval = setInterval(() => {
      const newStar: ShootingStar = {
        id: Date.now(),
        x: Math.random() * 80,
        y: Math.random() * 30,
      }
      setShootingStars(prev => [...prev, newStar])
      setTimeout(() => {
        setShootingStars(prev => prev.filter(s => s.id !== newStar.id))
      }, 1000)
    }, 4000)
    return () => clearInterval(interval)
  }, [mounted])

  const handleStarClick = useCallback((id: number) => {
    setStars(prev => prev.map(star => 
      star.id === id ? { ...star, size: star.size + 2 } : star
    ))
  }, [])

  if (!mounted) return null

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
      {/* Deep space gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a0015] via-[#1a0a2e] to-[#0d0d1a]" />
      
      {/* Nebula effects */}
      <div className="absolute top-0 left-0 w-full h-full opacity-30">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-pink-500/20 rounded-full blur-[120px] animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-purple-500/20 rounded-full blur-[100px] animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-blue-500/10 rounded-full blur-[80px] animate-pulse" style={{ animationDelay: '2s' }} />
      </div>

      {/* Stars */}
      {stars.map((star) => (
        <motion.div
          key={star.id}
          className="absolute rounded-full bg-white pointer-events-auto cursor-pointer"
          style={{
            left: `${star.x}%`,
            top: `${star.y}%`,
            width: star.size,
            height: star.size,
          }}
          animate={{
            opacity: [0.3, 1, 0.3],
            scale: [0.8, 1.2, 0.8],
          }}
          transition={{
            duration: star.duration,
            delay: star.delay,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          onClick={() => handleStarClick(star.id)}
          whileHover={{ scale: 2 }}
        />
      ))}

      {/* Floating hearts */}
      {hearts.map((heart) => (
        <motion.div
          key={heart.id}
          className="absolute text-pink-500/30 pointer-events-auto cursor-pointer"
          style={{
            left: `${heart.x}%`,
            top: `${heart.y}%`,
            fontSize: heart.size,
          }}
          animate={{
            y: [0, -30, 0],
            x: [0, 10, -10, 0],
            rotate: [0, 10, -10, 0],
            opacity: [0.2, 0.4, 0.2],
          }}
          transition={{
            duration: 8,
            delay: heart.delay,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          whileHover={{ scale: 1.5, opacity: 0.8 }}
        >
          ❤️
        </motion.div>
      ))}

      {/* Shooting stars */}
      <AnimatePresence>
        {shootingStars.map((star) => (
          <motion.div
            key={star.id}
            className="absolute w-1 h-1 bg-white rounded-full"
            style={{
              left: `${star.x}%`,
              top: `${star.y}%`,
            }}
            initial={{ opacity: 1, x: 0, y: 0 }}
            animate={{ 
              opacity: 0, 
              x: 300, 
              y: 300,
            }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1, ease: "easeOut" }}
          >
            <div className="absolute w-20 h-0.5 bg-gradient-to-r from-white to-transparent -rotate-45 origin-left" />
          </motion.div>
        ))}
      </AnimatePresence>

      {/* Constellation lines */}
      <svg className="absolute inset-0 w-full h-full opacity-10">
        <line x1="10%" y1="20%" x2="25%" y2="15%" stroke="white" strokeWidth="0.5" />
        <line x1="25%" y1="15%" x2="35%" y2="25%" stroke="white" strokeWidth="0.5" />
        <line x1="70%" y1="60%" x2="80%" y2="55%" stroke="white" strokeWidth="0.5" />
        <line x1="80%" y1="55%" x2="85%" y2="65%" stroke="white" strokeWidth="0.5" />
      </svg>
    </div>
  )
}
