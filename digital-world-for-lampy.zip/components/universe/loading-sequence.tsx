'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'

const LOADING_MESSAGES = [
  'Entering Lampy ❤ Rose Universe...',
  'Gathering stardust...',
  'Connecting hearts across dimensions...',
  'Loading infinite memories...',
  'Preparing your secret world...',
  'Almost there, love is loading...',
]

export function LoadingSequence({ onComplete }: { onComplete: () => void }) {
  const [stage, setStage] = useState(0)
  const [progress, setProgress] = useState(0)
  const [messageIndex, setMessageIndex] = useState(0)

  useEffect(() => {
    const progressInterval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(progressInterval)
          return 100
        }
        return prev + 1
      })
    }, 40)

    const messageInterval = setInterval(() => {
      setMessageIndex((prev) => (prev + 1) % LOADING_MESSAGES.length)
    }, 1500)

    return () => {
      clearInterval(progressInterval)
      clearInterval(messageInterval)
    }
  }, [])

  useEffect(() => {
    if (progress === 30) setStage(1)
    if (progress === 60) setStage(2)
    if (progress === 90) setStage(3)
    if (progress === 100) {
      setTimeout(onComplete, 800)
    }
  }, [progress, onComplete])

  return (
    <motion.div
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-background"
      exit={{ opacity: 0 }}
      transition={{ duration: 0.8 }}
    >
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-background via-deep-purple/20 to-background" />
      
      {/* Animated circles */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 rounded-full bg-pink-500/30"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              scale: [0, 1.5, 0],
              opacity: [0, 0.8, 0],
            }}
            transition={{
              duration: 3,
              delay: i * 0.2,
              repeat: Infinity,
            }}
          />
        ))}
      </div>

      {/* Main heart animation */}
      <motion.div className="relative z-10 flex flex-col items-center">
        <motion.div
          className="relative mb-8"
          initial={{ scale: 0, rotate: -180 }}
          animate={{ 
            scale: stage >= 1 ? 1 : 0.5,
            rotate: 0,
          }}
          transition={{ 
            type: 'spring',
            stiffness: 100,
            damping: 15,
            duration: 1
          }}
        >
          {/* Outer glow rings */}
          <motion.div
            className="absolute inset-0 -m-8 rounded-full"
            style={{
              background: 'radial-gradient(circle, rgba(255,105,180,0.3) 0%, transparent 70%)',
            }}
            animate={{
              scale: [1, 1.2, 1],
              opacity: [0.5, 0.8, 0.5],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
          />
          
          {/* Heart icon */}
          <motion.div
            className="text-8xl md:text-9xl"
            animate={{
              scale: [1, 1.1, 1],
            }}
            transition={{
              duration: 1.5,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
          >
            <span className="text-transparent bg-clip-text bg-gradient-to-br from-pink-400 via-pink-500 to-purple-500 drop-shadow-[0_0_30px_rgba(255,105,180,0.8)]">
              ❤
            </span>
          </motion.div>

          {/* Particle burst on stage changes */}
          <AnimatePresence>
            {stage > 0 && (
              <>
                {[...Array(12)].map((_, i) => (
                  <motion.div
                    key={`particle-${stage}-${i}`}
                    className="absolute left-1/2 top-1/2 w-2 h-2 rounded-full bg-pink-400"
                    initial={{ scale: 0, x: 0, y: 0 }}
                    animate={{
                      scale: [0, 1, 0],
                      x: Math.cos((i / 12) * Math.PI * 2) * 100,
                      y: Math.sin((i / 12) * Math.PI * 2) * 100,
                      opacity: [1, 0],
                    }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 1 }}
                  />
                ))}
              </>
            )}
          </AnimatePresence>
        </motion.div>

        {/* Title */}
        <motion.h1
          className="text-3xl md:text-5xl font-bold mb-4 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: stage >= 1 ? 1 : 0, y: stage >= 1 ? 0 : 20 }}
          transition={{ delay: 0.3 }}
        >
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-400 via-purple-400 to-pink-400 animate-gradient-shift">
            Lampy ❤ Rose
          </span>
        </motion.h1>

        {/* Subtitle */}
        <motion.div
          className="h-8 mb-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: stage >= 2 ? 1 : 0 }}
        >
          <AnimatePresence mode="wait">
            <motion.p
              key={messageIndex}
              className="text-muted-foreground text-lg md:text-xl"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
            >
              {LOADING_MESSAGES[messageIndex]}
            </motion.p>
          </AnimatePresence>
        </motion.div>

        {/* Progress bar */}
        <motion.div
          className="w-64 md:w-80 h-2 bg-muted rounded-full overflow-hidden"
          initial={{ opacity: 0, scaleX: 0 }}
          animate={{ opacity: 1, scaleX: 1 }}
          transition={{ delay: 0.5 }}
        >
          <motion.div
            className="h-full bg-gradient-to-r from-pink-500 via-purple-500 to-pink-500 rounded-full"
            style={{ width: `${progress}%` }}
            transition={{ duration: 0.1 }}
          />
        </motion.div>

        {/* Progress percentage */}
        <motion.p
          className="mt-4 text-sm text-muted-foreground font-mono"
          initial={{ opacity: 0 }}
          animate={{ opacity: stage >= 2 ? 1 : 0 }}
        >
          {progress}%
        </motion.p>
      </motion.div>
    </motion.div>
  )
}
