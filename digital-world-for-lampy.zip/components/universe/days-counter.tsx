'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'

interface DaysCounterProps {
  startDate?: string
}

export function DaysCounter({ startDate = '2024-01-01' }: DaysCounterProps) {
  const [days, setDays] = useState(0)
  const [time, setTime] = useState({ hours: 0, minutes: 0, seconds: 0 })

  useEffect(() => {
    const calculateDays = () => {
      const start = new Date(startDate)
      const now = new Date()
      const diff = now.getTime() - start.getTime()
      return Math.floor(diff / (1000 * 60 * 60 * 24))
    }

    setDays(calculateDays())

    const interval = setInterval(() => {
      const now = new Date()
      setTime({
        hours: now.getHours(),
        minutes: now.getMinutes(),
        seconds: now.getSeconds(),
      })
    }, 1000)

    return () => clearInterval(interval)
  }, [startDate])

  const formatTime = (num: number) => num.toString().padStart(2, '0')

  return (
    <motion.div
      className="glass rounded-2xl p-6 text-center"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.02 }}
    >
      <motion.div
        className="text-5xl md:text-6xl font-bold mb-2"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: 'spring', stiffness: 200, delay: 0.2 }}
      >
        <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-400 to-purple-400">
          {days}
        </span>
      </motion.div>
      <p className="text-muted-foreground text-sm mb-4">days of us</p>
      
      <div className="flex items-center justify-center gap-1 font-mono text-lg">
        <motion.span 
          className="bg-muted/50 px-2 py-1 rounded"
          key={time.hours}
          initial={{ y: -10, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
        >
          {formatTime(time.hours)}
        </motion.span>
        <span className="text-pink-400 animate-pulse">:</span>
        <motion.span 
          className="bg-muted/50 px-2 py-1 rounded"
          key={time.minutes}
          initial={{ y: -10, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
        >
          {formatTime(time.minutes)}
        </motion.span>
        <span className="text-pink-400 animate-pulse">:</span>
        <motion.span 
          className="bg-muted/50 px-2 py-1 rounded"
          key={time.seconds}
          initial={{ y: -10, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
        >
          {formatTime(time.seconds)}
        </motion.span>
      </div>
      
      <p className="text-xs text-muted-foreground mt-3">
        {new Date().toLocaleDateString('en-US', { 
          weekday: 'long', 
          year: 'numeric', 
          month: 'long', 
          day: 'numeric' 
        })}
      </p>
    </motion.div>
  )
}

export function RelationshipLevel() {
  const level = 42 // This could be calculated based on activities
  const xp = 7850
  const nextLevelXp = 10000

  return (
    <motion.div
      className="glass-pink rounded-2xl p-4"
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
    >
      <div className="flex items-center gap-3">
        <div className="relative">
          <motion.div
            className="w-12 h-12 rounded-full bg-gradient-to-br from-pink-500 to-purple-500 flex items-center justify-center text-white font-bold"
            animate={{ 
              boxShadow: [
                '0 0 0 0 rgba(255, 105, 180, 0.4)',
                '0 0 0 10px rgba(255, 105, 180, 0)',
              ]
            }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            {level}
          </motion.div>
        </div>
        <div className="flex-1">
          <p className="text-sm font-medium">Relationship Level</p>
          <div className="flex items-center gap-2">
            <div className="flex-1 h-2 bg-muted/50 rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-pink-500 to-purple-500"
                initial={{ width: 0 }}
                animate={{ width: `${(xp / nextLevelXp) * 100}%` }}
                transition={{ duration: 1, delay: 0.5 }}
              />
            </div>
            <span className="text-xs text-muted-foreground">
              {xp}/{nextLevelXp}
            </span>
          </div>
        </div>
      </div>
    </motion.div>
  )
}
